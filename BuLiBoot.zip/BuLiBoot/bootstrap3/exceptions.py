# -*- coding: utf-8 -*-
from __future__ import unicode_literals


class BootstrapException(Exception):
    pass


class BootstrapError(BootstrapException):
    pass
